module com.example.homeharmonyhero {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    opens com.example.homeharmonyhero.data to javafx.base;
    opens com.example.homeharmonyhero to javafx.fxml;
    exports com.example.homeharmonyhero.data;
    exports com.example.homeharmonyhero;
}