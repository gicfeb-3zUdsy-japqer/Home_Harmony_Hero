package com.example.homeharmonyhero.data;

public class Task {
    private  int taskId;
    private  String taskName;
    private  Roommate assignedTo;
    private String taskStatus;

    public Task(int taskId, String taskName, Roommate assignedTo, String taskStatus) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.assignedTo = assignedTo;
        this.taskStatus = taskStatus;
    }
    public Task( String taskName, Roommate assignedTo, String taskStatus) {
        this.taskName = taskName;
        this.assignedTo = assignedTo;
        this.taskStatus = taskStatus;
    }
    public int getTaskId() {
        return taskId;
    }
    public String getTaskName() {
        return taskName;
    }
    public Roommate getAssignedTo() {
        return assignedTo;
    }
    public String getTaskStatus() {
        return taskStatus;
    }
    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus;
    }
    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }
    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }
    public void setAssignedTo(Roommate assignedTo) {
        this.assignedTo = assignedTo;
    }
}