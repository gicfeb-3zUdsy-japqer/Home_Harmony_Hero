package com.example.homeharmonyhero;

import com.example.homeharmonyhero.data.Roommate;
import com.example.homeharmonyhero.data.ShoppingList;
import com.example.homeharmonyhero.logic.DBService;
import com.example.homeharmonyhero.logic.ShoppingListService;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.*;

import java.util.Optional;

public class ControllerUtils {
    public static Roommate selectedRoommate;
    static DBService dbService= new DBService();
    static ShoppingListService shoppingListService= new ShoppingListService();

    protected static ObservableList <Roommate> roommates;
    public static void addRoommatesToSplitMenuButton(SplitMenuButton smbAssignedTo, ObservableList <Roommate> roommates, EventHandler<ActionEvent> onAssignedToMenuItemClick) {
      roommates= dbService.loadRoommatesFromDB();
      smbAssignedTo.getItems().clear();
      for (Roommate roommate : roommates) {
          MenuItem item = new MenuItem(roommate.getRoommateName());
          item.setOnAction(event -> {
              selectedRoommate =roommate;
              smbAssignedTo.setText(roommate.getRoommateName());
          });
          smbAssignedTo.getItems().add(item);
      }
    }
    public static void onMarkAsStatusMenuItemClick(ActionEvent event, SplitMenuButton splitMenuButton) {
      MenuItem item = (MenuItem) event.getSource();
      String taskStatus = item.getText();
      splitMenuButton.setText(taskStatus);
    }
    public static void onAssignedToMenuItemClick(ActionEvent event, SplitMenuButton splitMenuButton, ObservableList<Roommate> roommates) {
      MenuItem item = (MenuItem) event.getSource();
      String selectedRoommateName = item.getText();
      Roommate selectedRoommate = roommates.stream()
              .filter(roommate -> roommate.getRoommateName().equals(selectedRoommateName))
              .findFirst().orElse(null);
      if (selectedRoommate != null) {
          splitMenuButton.setText(selectedRoommateName);
      }
    }
    public static void onRoommateSplitMenuClick(ActionEvent event,
                                              SplitMenuButton smbAddedByNames,
                                              ObservableList <Roommate> roommates,
                                              TextField tfProductInput,
                                              TextField tfQuantity,
                                              ObservableList<ShoppingList> shoppingList,
                                              TableView<ShoppingList> tvShoppingList) {
        MenuItem item = (MenuItem) event.getSource();
        String selectedRoommateName = item.getText();
        Optional<Integer> quantityOptional = getQuantityFromTf(tfQuantity);
        if (quantityOptional.isPresent()) {
            int quantity = quantityOptional.get();
            selectedRoommate = roommates.stream()
                  .filter(roommate -> roommate.getRoommateName().equals(selectedRoommateName))
                  .findFirst().orElse(null);
            if (selectedRoommate != null) {
                smbAddedByNames.setText(selectedRoommateName);
                ShoppingList newProduct = new ShoppingList(tfProductInput.getText(), quantity, selectedRoommate);
                if (!newProduct.getProductName().isEmpty() && newProduct.getQuantity() > 0) {
                    shoppingListService.addProductToShoppingList(newProduct);
                    shoppingList.add(newProduct);
                    tfProductInput.clear();
                    tfQuantity.clear();
                    tvShoppingList.setItems(shoppingList);
                    tvShoppingList.refresh();
                }
            } else {
                System.out.println("Fehler-SplitMenu");
            }
        }
    }
    public static Optional<Integer> getQuantityFromTf(TextField tfQuantity) {
        String input = tfQuantity.getText();

        if (!input.isEmpty() && input.matches("\\d+")) {
            return Optional.of(Integer.parseInt(input));
        } else {
            System.out.println("Ungültige Eingabe für Menge");
            return Optional.empty();
        }
    }
    public static void setButtonTooltip(Button button) {
        Tooltip tooltip = new Tooltip("deletes the selected roommate");
        button.setTooltip(tooltip);
    }
}