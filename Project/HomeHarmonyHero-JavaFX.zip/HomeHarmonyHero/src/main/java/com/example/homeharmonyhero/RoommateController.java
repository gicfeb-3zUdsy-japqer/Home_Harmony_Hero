package com.example.homeharmonyhero;

import com.example.homeharmonyhero.data.Roommate;
import com.example.homeharmonyhero.logic.DBService;
import com.example.homeharmonyhero.logic.RoommateService;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;

public class RoommateController {
    @FXML
    private TableView<Roommate> tvRoommates;

    @FXML
    private TableColumn <Roommate,Integer> colRoommateId;

    @FXML
    private TableColumn <Roommate,String> colRoommateName;

    @FXML
    private TextField nameInput;

    @FXML
    private Label welcomeLabel;

    @FXML
    private Button deleteRoommateButton;
    DBService dbService= new DBService();
    RoommateService roommateService= new RoommateService();

    @FXML
    public void initialize() {
        dbService.loadRoommatesFromDB();
        colRoommateId.setCellValueFactory(new PropertyValueFactory<>("roommateId"));
        colRoommateName.setCellValueFactory(new PropertyValueFactory<>("roommateName"));
        tvRoommates.setItems(dbService.roommates);
        ControllerUtils.setButtonTooltip(deleteRoommateButton);
    }
    @FXML
    public void onAddRoommateClick() {
        String roommate = nameInput.getText();
        if (!roommate.isEmpty()) {
            roommateService.addRoommateToDB(roommate);
            roommateService.addRoommate(roommate);
            dbService.loadRoommatesFromDB();
            tvRoommates.setItems(dbService.roommates);
            nameInput.clear();
        }
    }
    @FXML
    public void onDeleteRoommateClick() {
        Roommate selectedRoommate = tvRoommates.getSelectionModel().getSelectedItem();
        if (selectedRoommate != null) {
            roommateService.deleteRoommateFromDB(selectedRoommate);
            roommateService.deleteRoommate(selectedRoommate);
            dbService.loadRoommatesFromDB();
            tvRoommates.setItems(dbService.roommates);
        } else {
            Tooltip warningTooltip = new Tooltip("please select a roommate");
            Tooltip.install(deleteRoommateButton, warningTooltip);
            System.out.println("Sie haben keinen Mitbewohner zum löschen ausgewählt.");
        }
    }

    @FXML
    protected void onPreviousButtonClick() throws IOException {
        Stage stage= (Stage) welcomeLabel.getScene().getWindow();
        Parent root= FXMLLoader.load(getClass().getResource("hello-view.fxml"));
        Scene scene= new Scene(root);
        stage.setScene(scene);
    }
}