package com.example.homeharmonyhero;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.io.IOException;

public class HelloController {
    @FXML
    private AnchorPane anchorPane;

    @FXML
    protected void onGoToRoommatesClick() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("roommates-view.fxml"));
        applyFadeTransition(root);
    }
    @FXML
    protected void onGoToShoppingListClick() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("shoppingList-view.fxml"));
        applyFadeTransition(root);
    }
    @FXML
    protected void onGoToTasksClick() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("tasks-view.fxml"));
        applyFadeTransition(root);
    }
    private void applyFadeTransition(Parent root) {
        Scene newScene = new Scene(root);
        newScene.setFill(new LinearGradient(0, 0, 1, 0, true, CycleMethod.NO_CYCLE,
                new Stop(0, Color.LIGHTBLUE), new Stop(1, Color.DARKBLUE)));

        Stage stage = (Stage) anchorPane.getScene().getWindow();

        FadeTransition fadeOut = createFadeTransition(root, 1, 0, 0.5, () -> {
            stage.setScene(newScene);
            createFadeTransition(root, 0, 1, 0.5, () -> {}).play();
        });
        fadeOut.play();
    }
    private FadeTransition createFadeTransition(Parent node, double fromValue, double toValue, double duration, Runnable onFinished) {
        FadeTransition fadeTransition = new FadeTransition(Duration.seconds(duration), node);
        fadeTransition.setFromValue(fromValue);
        fadeTransition.setToValue(toValue);
        fadeTransition.setOnFinished(e -> {
            node.setOpacity(toValue);
            onFinished.run();
        });
        return fadeTransition;
    }
}