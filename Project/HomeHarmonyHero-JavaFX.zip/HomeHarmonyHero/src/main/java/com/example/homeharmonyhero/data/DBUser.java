package com.example.homeharmonyhero.data;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class DBUser {
    private final String dbUrl;
    private final String user;
    private final String pw;

    public DBUser() {
        List<String> fileAlreadyRead = readTextFile();
        this.dbUrl = fileAlreadyRead.get(0).split(" ")[1];
        this.user = fileAlreadyRead.get(1).split(" ")[1];
        this.pw = fileAlreadyRead.get(2).split(" ")[1];
    }
    public String getDbUrl() {
        return dbUrl;
    }

    public String getUser() {
        return user;
    }

    public String getPw() {
        return pw;
    }

    public List<String> readTextFile() {
        String fileName = "DBSettings/settings.txt";
        List<String> contents = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;

            while ((line = br.readLine()) != null) {
                contents.add(line);
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
        return contents;
    }
}
