package com.example.homeharmonyhero.logic;

import com.example.homeharmonyhero.data.Roommate;
import com.example.homeharmonyhero.data.Task;
public interface TaskEditCondition {
    void execute(Task selectedTask, TaskService taskService, Roommate newAssignedTo, String newStatus, String newTaskName);
}