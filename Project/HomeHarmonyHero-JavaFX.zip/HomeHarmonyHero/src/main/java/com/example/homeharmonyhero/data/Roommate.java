package com.example.homeharmonyhero.data;

public class Roommate {
    private final int roommateId;
    private final String roommateName;

    public Roommate(int roommateId, String roommateName) {
        this.roommateId = roommateId;
        this.roommateName = roommateName;
    }
    public int getRoommateId() {
        return roommateId;
    }
    public String getRoommateName() {
        return roommateName;
    }

    @Override
    public String toString() {
        return getRoommateName();
    }
}
