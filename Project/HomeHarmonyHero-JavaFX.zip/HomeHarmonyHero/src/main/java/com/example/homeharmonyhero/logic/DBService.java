package com.example.homeharmonyhero.logic;
import com.example.homeharmonyhero.data.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;

public class DBService {
    private final DBUser dbUser = new DBUser();
    public ObservableList<Task> tasksList = FXCollections.observableArrayList();

    public ObservableList<Roommate> roommates = FXCollections.observableArrayList();
    public ObservableList<ShoppingList> shoppingList = FXCollections.observableArrayList();
    DBConnection dbConnection = new DBConnection(dbUser.getDbUrl(), dbUser.getUser(), dbUser.getPw());
    public DBService() {
        loadRoommatesFromDB();
        loadTasksFromDB();
        loadShoppingListFromDB();
    }
    public ObservableList<Roommate> loadRoommatesFromDB() {
        roommates.clear();
        try (Connection connection = DriverManager.getConnection(dbConnection.dbUrl(), dbConnection.user(), dbConnection.pw());
             Statement statement = connection.createStatement()) {
            ResultSet resultSetRoommates = statement.executeQuery("SELECT * FROM Roommates");
            while (resultSetRoommates.next()) {
                int roommateId = resultSetRoommates.getInt("roommateId");
                String roommateName = resultSetRoommates.getString("roommateName");
                Roommate roommate = new Roommate(roommateId, roommateName);
                roommates.add(roommate);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return roommates;
    }
    public ObservableList<Task> loadTasksFromDB() {
        roommates = loadRoommatesFromDB();
        tasksList.clear();

        try (Connection connection = DriverManager.getConnection(dbConnection.dbUrl(), dbConnection.user(), dbConnection.pw());
             Statement statement = connection.createStatement()) {
            ResultSet resultSet= statement.executeQuery("SELECT t.taskId, t.taskName, t.assignedTo, t.taskStatus, r.roommateName FROM Tasks t INNER JOIN Roommates r ON t.assignedTo = r.roommateId");
            while (resultSet.next()) {
                int taskId= resultSet.getInt("taskId");
                String taskName = resultSet.getString("taskName");
                Roommate assignedTo= new Roommate(resultSet.getInt("assignedTo"), resultSet.getString("roommateName"));
                String taskStatus = resultSet.getString("taskStatus");
                Task task = new Task(taskId,taskName, assignedTo, taskStatus);
                tasksList.add(task);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } return tasksList;
    }
    public Roommate getRoommateByName(String roommateName) {
        return roommates.stream()
                .filter(roommate -> roommate.getRoommateName().equalsIgnoreCase(roommateName))
                .findFirst()
                .orElse(null);
    }
    public ObservableList <ShoppingList> loadShoppingListFromDB(){
        roommates =loadRoommatesFromDB();
        shoppingList.clear();

        try (Connection connection = DriverManager.getConnection(dbConnection.dbUrl(),dbConnection.user(), dbConnection.pw());
             Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery("SELECT s.productId, s.productName, s.quantity, s.addedBy, r.roommateName FROM ShoppingList s INNER JOIN Roommates r ON s.addedBy = r.roommateId");
            while (resultSet.next()) {
                int productId = resultSet.getInt("productId");
                String productName = resultSet.getString("productName");
                int quantity = resultSet.getInt("quantity");
                Roommate addedBy = new Roommate(resultSet.getInt("addedBy"), resultSet.getString("roommateName"));
                ShoppingList product= new ShoppingList(productId,productName,quantity,addedBy);
                shoppingList.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return shoppingList;
    }
}