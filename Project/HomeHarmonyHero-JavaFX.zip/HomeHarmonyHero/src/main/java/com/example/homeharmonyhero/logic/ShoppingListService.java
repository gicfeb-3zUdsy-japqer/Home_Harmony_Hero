package com.example.homeharmonyhero.logic;
import com.example.homeharmonyhero.data.*;
import javafx.collections.ObservableList;

import java.sql.*;
public class ShoppingListService {
    private final DBUser dbUser = new DBUser();
    DBConnection dbConnection = new DBConnection(dbUser.getDbUrl(), dbUser.getUser(), dbUser.getPw());
    DBService dbService = new DBService();
    public ObservableList<ShoppingList> shoppingList = dbService.shoppingList;

    public ObservableList<Roommate> roommates = dbService.roommates;
    public ShoppingListService() {
        dbService.loadRoommatesFromDB();
    }
    private int getRoommateId(String roommateName) {
        return roommates.stream()
                .filter(roommate -> roommate.getRoommateName().equalsIgnoreCase(roommateName))
                .findFirst()
                .map(Roommate::getRoommateId)
                .orElse(-1);
    }
    public void addProductToDB(String productName, int quantity, String addedBy) {
        Roommate addedByName = dbService.getRoommateByName(addedBy);
        if (addedByName == null) {
            System.out.println("Zugewiesene Name des Mitbewohners ist ungültig");
            return;
        }
        try (Connection connection = DriverManager.getConnection(dbConnection.dbUrl(), dbConnection.user(), dbConnection.pw());
             PreparedStatement statement = connection.prepareStatement("INSERT INTO ShoppingList (productName, quantity, addedBy) VALUES (?,?,?)")) {
            statement.setString(1, productName);
            statement.setInt(2, quantity);
            statement.setInt(3, addedByName.getRoommateId());
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                ShoppingList newProduct = new ShoppingList(productName, quantity, addedByName);
                shoppingList.add(newProduct);
                System.out.println("Neues Produkt erfolgreich zur Datenbank hinzugefügt.");
            } else {
                System.out.println("Fehler beim Hinzufügen des neuen Produkts zur Datenbank.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void editProductNameInDB(ShoppingList product, String newProductName) {
        try (Connection connection = DriverManager.getConnection(dbConnection.dbUrl(), dbConnection.user(), dbConnection.pw());
             PreparedStatement statement = connection.prepareStatement("UPDATE ShoppingList SET productName=? WHERE productId=?")) {
            statement.setString(1, newProductName);
            statement.setInt(2, product.getProductId());
            statement.executeUpdate();
            product.setProductName(newProductName);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void editQuantityInDB(ShoppingList product, int newQuantity) {
        try (Connection connection = DriverManager.getConnection(dbConnection.dbUrl(), dbConnection.user(), dbConnection.pw());
             PreparedStatement statement = connection.prepareStatement("UPDATE ShoppingList SET quantity=? WHERE productId=?")) {
            statement.setInt(1, newQuantity);
            statement.setInt(2, product.getProductId());
            statement.executeUpdate();
            product.setQuantity(newQuantity);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void editAddedByInDB(ShoppingList product, String newAddedBy) {
        int addedById = getRoommateId(newAddedBy);
        if (addedById == -1) {
            System.out.println("Zugewiesener Mitbewohner zur Bearbeitung ist ungültig");
            return;
        }
        try (Connection connection = DriverManager.getConnection(dbConnection.dbUrl(), dbConnection.user(), dbConnection.pw());
             PreparedStatement statement = connection.prepareStatement("UPDATE ShoppingList SET addedBy=? WHERE productId=?")) {
            statement.setInt(1, addedById);
            statement.setInt(2, product.getProductId());
            statement.executeUpdate();
            Roommate newRoommate = roommates.stream()
                    .filter(roommate -> roommate.getRoommateName().equalsIgnoreCase(newAddedBy))
                    .findFirst()
                    .orElse(null);
            if (newRoommate != null) {
                product.setAddedBy(newRoommate);
            } else {
                System.out.println("Neuer Mitbewohner nicht gefunden");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void deleteProductFromDB(ShoppingList product) {
        try (Connection connection = DriverManager.getConnection(dbConnection.dbUrl(), dbConnection.user(), dbConnection.pw());
             PreparedStatement statement = connection.prepareStatement("DELETE FROM ShoppingList WHERE productName=?")) {
            statement.setString(1, product.getProductName());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void addProductToShoppingList(ShoppingList newProduct) {
        shoppingList.add(newProduct);
        addProductToDB(newProduct.getProductName(), newProduct.getQuantity(), String.valueOf(newProduct.getAddedBy()));
    }
    public void editProductInDB(ShoppingList product, String newProductName, int newQuantity, Roommate newAddedBy) {
        if (newProductName != null && !newProductName.isEmpty()) {
            editProductNameInDB(product, newProductName);
        }
        if (newQuantity > 0) {
            editQuantityInDB(product, newQuantity);
        }
        if (newAddedBy != null) {
            editAddedByInDB(product, newAddedBy.getRoommateName());
        }
    }
    public void deleteProductFromShoppingList(ShoppingList product) {
        deleteProductFromDB(product);
    }
}
