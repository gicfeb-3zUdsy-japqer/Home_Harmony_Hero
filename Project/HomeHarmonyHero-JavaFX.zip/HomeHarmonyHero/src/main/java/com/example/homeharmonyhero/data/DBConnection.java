package com.example.homeharmonyhero.data;

public record DBConnection(String dbUrl, String user, String pw) {
}