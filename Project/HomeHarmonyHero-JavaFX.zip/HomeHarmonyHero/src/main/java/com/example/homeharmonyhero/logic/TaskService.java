package com.example.homeharmonyhero.logic;

import com.example.homeharmonyhero.data.DBConnection;
import com.example.homeharmonyhero.data.DBUser;
import com.example.homeharmonyhero.data.Roommate;
import com.example.homeharmonyhero.data.Task;
import javafx.collections.ObservableList;
import java.sql.*;

public class TaskService {
    private final DBUser dbUser = new DBUser();
    DBConnection dbConnection = new DBConnection(dbUser.getDbUrl(), dbUser.getUser(), dbUser.getPw());
    DBService dbService = new DBService();
    public ObservableList<Task> tasksList = dbService.tasksList;

    public ObservableList<Roommate> roommates = dbService.roommates;
    public TaskService() {
        dbService.loadTasksFromDB();
    }
    private int getRoommateId(String roommateName) {
        return roommates.stream()
                .filter(roommate -> roommate.getRoommateName().equalsIgnoreCase(roommateName))
                .findFirst()
                .map(Roommate::getRoommateId)
                .orElse(-1);
    }
    public void addTaskToDB(String taskName, String assignedToName, String taskStatus) {
        Roommate assignedTo = dbService.getRoommateByName(assignedToName);
        if (assignedTo == null) {
            System.out.println("Zugewiesene Name des Mitbewohners ist ungültig");
            return;
        }
        try (Connection connection = DriverManager.getConnection(dbConnection.dbUrl(), dbConnection.user(), dbConnection.pw());
             PreparedStatement statement = connection.prepareStatement("INSERT INTO Tasks (taskName, assignedTo, taskStatus) VALUES (?,?,?)")) {
            statement.setString(1, taskName);
            statement.setInt(2, assignedTo.getRoommateId());
            statement.setString(3, taskStatus);
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                Task newTask = new Task(taskName, assignedTo, taskStatus);
                tasksList.add(newTask);
                System.out.println("Aufgabe erfolgreich zur Datenbank hinzugefügt.");
            } else {
                System.out.println("Fehler beim Hinzufügen der Aufgabe zur Datenbank.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void editTaskNameToDB(Task task, String newTaskName) {
        try (Connection connection = DriverManager.getConnection(dbConnection.dbUrl(), dbConnection.user(), dbConnection.pw());
             PreparedStatement statement = connection.prepareStatement("UPDATE Tasks SET taskName=? WHERE taskId=?")) {
            statement.setString(1, newTaskName);
            statement.setInt(2, task.getTaskId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void editAssignedToToDB(Task task, String newAssignedTo) {
        int assignedToId = getRoommateId(newAssignedTo);
        if (assignedToId == -1) {
            System.out.println("Zugewiesener Mitbewohner zur Bearbeitung ist ungültig");
            return;
        }
        try (Connection connection = DriverManager.getConnection(dbConnection.dbUrl(), dbConnection.user(), dbConnection.pw());
             PreparedStatement statement = connection.prepareStatement("UPDATE Tasks SET assignedTo=? WHERE taskId=?")) {
            statement.setInt(1, assignedToId);
            statement.setInt(2, task.getTaskId());
            statement.executeUpdate();
            dbService.loadTasksFromDB();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void editStatusToDB(Task task, String newStatus) {
        try (Connection connection = DriverManager.getConnection(dbConnection.dbUrl(), dbConnection.user(), dbConnection.pw());
             PreparedStatement statement = connection.prepareStatement("UPDATE Tasks SET taskStatus=? WHERE taskId=?")) {
            statement.setString(1, newStatus);
            statement.setInt(2, task.getTaskId());
            statement.executeUpdate();
            dbService.loadTasksFromDB();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void deleteTaskFromDB(Task task) {
        try (Connection connection = DriverManager.getConnection(dbConnection.dbUrl(), dbConnection.user(), dbConnection.pw());
             PreparedStatement statement = connection.prepareStatement("DELETE FROM Tasks WHERE taskName=?")) {
            statement.setString(1, task.getTaskName());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void markTaskStatusToDB(Task task, String taskStatus) {
        try (Connection connection = DriverManager.getConnection(dbConnection.dbUrl(), dbConnection.user(), dbConnection.pw());
             PreparedStatement statement = connection.prepareStatement("UPDATE Tasks SET taskStatus=? WHERE taskId=?")) {
            task.setTaskStatus(taskStatus);
            statement.setString(1, taskStatus);
            statement.setInt(2, task.getTaskId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void addTask(Task newTask) {
        tasksList.add(newTask);
        addTaskToDB(newTask.getTaskName(), String.valueOf(newTask.getAssignedTo()), newTask.getTaskStatus());
    }
    public String getTaskStatusFromSplitMenu(String buttonText) {
        return buttonText;
    }
    public void deleteTask(Task task) {
        deleteTaskFromDB(task);
    }
    public void markTaskStatus(Task task, String taskStatus) {
        markTaskStatusToDB(task, taskStatus);
        Task updatedTask = tasksList.stream()
                .filter(t -> t.getTaskId() == task.getTaskId())
                .findFirst()
                .orElse(null);

        if(updatedTask != null) {
            updatedTask.setTaskStatus(taskStatus);
        }
        int index = tasksList.indexOf(task);
        tasksList.set(index,updatedTask);
    }
}