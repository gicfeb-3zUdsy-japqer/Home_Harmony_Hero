package com.example.homeharmonyhero;

import com.example.homeharmonyhero.data.Roommate;
import com.example.homeharmonyhero.data.SplitMenuButtonElements;
import com.example.homeharmonyhero.data.Task;
import com.example.homeharmonyhero.logic.*;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class EditTaskController {
    @FXML
    private TableView<Task> tvTasksList;

    @FXML
    private TableColumn<Task, Integer> colTaskId;

    @FXML
    private TableColumn<Task, String> colTask;

    @FXML
    private TableColumn<Task, Roommate> colAssignedTo;

    @FXML
    private TableColumn<Task, String> colStatus;

    @FXML
    private TextField tfTaskName;

    @FXML
    protected SplitMenuButton smbStatus;

    @FXML
    private SplitMenuButton smbAssignedTo;

    @FXML
    private Button okButton;
    TaskService taskService = new TaskService();
    DBService dbService = new DBService();
    private TaskController taskController;
    TaskEditCondition taskNameEditCondition = new TaskNameEditCondition();
    TaskEditCondition assignedToEditCondition = new AssignedToEditCondition();
    TaskEditCondition statusEditCondition = new StatusEditCondition();

    public ObservableList<Roommate> roommates = dbService.loadRoommatesFromDB();
    private  ObservableList<Task> selectedTasks;
    public void setSelectedTasks(ObservableList <Task> selectedTasks) {
        this.selectedTasks = selectedTasks;
    }
    public void setTaskController(TaskController taskController) {
        this.taskController = taskController;
    }
    public void initialize() {
        addElementsToSplitMenuButton();
        addRoommatesToSplitMenuButton();
        tvTasksList.setItems(selectedTasks);
        tvTasksList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        colTaskId.setCellValueFactory(new PropertyValueFactory<>("taskId"));
        colTask.setCellValueFactory(new PropertyValueFactory<>("taskName"));
        colAssignedTo.setCellValueFactory(new PropertyValueFactory<>("assignedTo"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("taskStatus"));
        setButtonTooltips();
    }
    public void addElementsToSplitMenuButton() {
        SplitMenuButtonElements.addElementsToSplitMenuButton(smbStatus, this::onMarkAsStatusMenuItemClick,
                SplitMenuButtonElements.ERLEDIGT, SplitMenuButtonElements.AUSSTEHEND, SplitMenuButtonElements.IN_ARBEIT);
    }
    public void addRoommatesToSplitMenuButton() {
        ControllerUtils.addRoommatesToSplitMenuButton(smbAssignedTo, roommates, this::onAssignedToMenuItemClick);
    }
    @FXML
    public void onMarkAsStatusMenuItemClick(ActionEvent event) {
        ControllerUtils.onMarkAsStatusMenuItemClick(event, smbStatus);
    }
    @FXML
    public void onAssignedToMenuItemClick(ActionEvent event) {
        ControllerUtils.onAssignedToMenuItemClick(event, smbAssignedTo, roommates);
    }
    @FXML
    public void onOKEditButtonClick() {
        ObservableList<Task> selectedTasks = tvTasksList.getSelectionModel().getSelectedItems();
        for (Task selectedTask : selectedTasks) {
            String newTaskName = tfTaskName.getText();
            Roommate newAssignedTo = roommates.stream()
                    .filter(roommate -> roommate.getRoommateName().equals(smbAssignedTo.getText()))
                    .findFirst().orElse(null);
            String newStatus = taskService.getTaskStatusFromSplitMenu(smbStatus.getText());

            taskNameEditCondition.execute(selectedTask, taskService, newAssignedTo, newStatus, newTaskName);
            assignedToEditCondition.execute(selectedTask, taskService, newAssignedTo, newStatus, newTaskName);
            statusEditCondition.execute(selectedTask, taskService, newAssignedTo, newStatus, newTaskName);

            tvTasksList.refresh();
            clearTextFields();
            resetSplitMenuButton();

            Tooltip warningTooltip = new Tooltip("please select the task to edit");
            Tooltip.install(okButton, warningTooltip);
        }
    }
    public void onCloseWindow() {
        List<Task> completedTasks = new ArrayList<>(tvTasksList.getItems())
                .stream()
                .filter(task -> task.getTaskStatus().equals("erledigt"))
                .collect(Collectors.toList());

        for (Task completedTask : completedTasks) {
            taskService.deleteTaskFromDB(completedTask);
            taskController.updateTasksListAfterEdit(completedTask);
        }
    }
    private void resetSplitMenuButton() {
        smbAssignedTo.setText("Roommates");
    }
    private void setButtonTooltips() {
        Tooltip tooltip = new Tooltip("save editing");
        okButton.setTooltip(tooltip);
    }
    private void clearTextFields() {
        tfTaskName.clear();
    }
}