package com.example.homeharmonyhero.data;

public class ShoppingList {
    private int productId;
    private String productName;
    private int quantity;
    private Roommate addedBy;
    public ShoppingList(int productId, String productName, int quantity, Roommate addedBy) {
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.addedBy = addedBy;
    }
    public ShoppingList(String productName, int quantity, Roommate addedBy) {
        this.productName = productName;
        this.quantity = quantity;
        this.addedBy = addedBy;
    }
    public int getProductId() {
        return productId;
    }
    public String getProductName() {
        return productName;
    }
    public int getQuantity() {
        return quantity;
    }
    public Roommate getAddedBy() {
        return addedBy;
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public void setAddedBy(Roommate addedBy) {
        this.addedBy = addedBy;
    }
}