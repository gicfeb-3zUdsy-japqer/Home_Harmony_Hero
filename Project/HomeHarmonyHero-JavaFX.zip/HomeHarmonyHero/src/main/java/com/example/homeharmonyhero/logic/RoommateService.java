package com.example.homeharmonyhero.logic;
import com.example.homeharmonyhero.data.DBConnection;
import com.example.homeharmonyhero.data.DBUser;
import com.example.homeharmonyhero.data.Roommate;
import javafx.collections.ObservableList;
import java.sql.*;

public class RoommateService {
    private final DBUser dbUser = new DBUser();
    DBConnection dbConnection = new DBConnection(dbUser.getDbUrl(), dbUser.getUser(), dbUser.getPw());
    DBService dbService= new DBService();

    public ObservableList <Roommate> roommates= dbService.roommates;
    public void loadRoommatesFromDB() {
        roommates.clear();
        roommates.addAll(dbService.roommates);
    }
    public void addRoommateToDB (String roommateName) {
        try (Connection connection = DriverManager.getConnection(dbConnection.dbUrl(), dbConnection.user(), dbConnection.pw());
             PreparedStatement statement = connection.prepareStatement("INSERT INTO Roommates (roommateName) VALUES (?)")) {
            statement.setString(1, roommateName);
            statement.executeUpdate();
            loadRoommatesFromDB();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void deleteRoommateFromDB (Roommate roommate) {
        try (Connection connection = DriverManager.getConnection(dbConnection.dbUrl(), dbConnection.user(), dbConnection.pw());
             PreparedStatement statement = connection.prepareStatement("DELETE FROM Roommates WHERE roommateId=?")) {
            statement.setInt(1, roommate.getRoommateId());
            statement.executeUpdate();
            loadRoommatesFromDB();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void addRoommate (String roommateName) {
        Roommate newRoommate= new Roommate(roommates.size() + 1,roommateName);
        roommates.add(newRoommate);
    }
    public void deleteRoommate (Roommate roommate) {
        roommates.remove(roommate);
    }
}