package com.example.homeharmonyhero.data;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SplitMenuButton;

public enum SplitMenuButtonElements {
    AUSSTEHEND("ausstehend"),
    IN_ARBEIT("in Arbeit"),
    ERLEDIGT("erledigt");
    private final String status;
    SplitMenuButtonElements(String status) {
        this.status = status;
    }
    public String getStatus() {
        return status;
    }
    public static void addElementsToSplitMenuButton(SplitMenuButton button, EventHandler<ActionEvent> eventHandler, SplitMenuButtonElements... elements) {
        if (button == null) {
            return;
        }
        button.getItems().clear();
        for (SplitMenuButtonElements element : elements) {
            MenuItem item = new MenuItem(element.getStatus());
            item.setOnAction(eventHandler);
            button.getItems().add(item);
        }
    }
}