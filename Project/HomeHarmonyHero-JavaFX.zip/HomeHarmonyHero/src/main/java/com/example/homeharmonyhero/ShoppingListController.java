package com.example.homeharmonyhero;

import com.example.homeharmonyhero.data.Roommate;
import com.example.homeharmonyhero.data.ShoppingList;
import com.example.homeharmonyhero.logic.DBService;
import com.example.homeharmonyhero.logic.RoommateService;
import com.example.homeharmonyhero.logic.ShoppingListService;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Optional;
import java.util.function.UnaryOperator;
import java.util.regex.Pattern;

public class ShoppingListController {
    @FXML
    private TableView<ShoppingList> tvShoppingList;

    @FXML
    private TableColumn<ShoppingList, Integer> colProductId;

    @FXML
    private TableColumn<ShoppingList, String> colProductName;

    @FXML
    private TableColumn<ShoppingList, Integer> colQuantity;

    @FXML
    private TableColumn<ShoppingList, Roommate> colAddedBy;

    @FXML
    private TextField tfProductInput;

    @FXML
    private TextField tfQuantity;

    @FXML
    private Label welcomeLabel;

    @FXML
    private SplitMenuButton smbAddedByNames;

    @FXML
    private Button addProductButton;

    @FXML
    private Button editProductButton;

    @FXML
    private Button deleteProductButton;
    DBService dbService = new DBService();
    ShoppingListService shoppingListService = new ShoppingListService();
    RoommateService roommateService = new RoommateService();

    public ObservableList<Roommate> roommates = roommateService.roommates;
    public ObservableList<ShoppingList> shoppingList = shoppingListService.shoppingList;

    @FXML
    public void initialize() {
        addRoommatesToSplitMenuButton();
        dbService.loadShoppingListFromDB();

        tvShoppingList.setItems(dbService.loadShoppingListFromDB());
        tvShoppingList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        colProductId.setCellValueFactory(new PropertyValueFactory<>("productId"));
        colProductName.setCellValueFactory(new PropertyValueFactory<>("productName"));
        colQuantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        colAddedBy.setCellValueFactory(new PropertyValueFactory<>("addedBy"));

        setButtonTooltips();
    }
    public void addRoommatesToSplitMenuButton() {
        ControllerUtils.addRoommatesToSplitMenuButton(smbAddedByNames, roommates, this::onRoommateSplitMenuClick);
    }
    @FXML
    public void onRoommateSplitMenuClick(ActionEvent event) {
        ControllerUtils.onRoommateSplitMenuClick(event, smbAddedByNames, roommates, tfProductInput, tfQuantity,shoppingList,tvShoppingList);
    }
    @FXML
    public void onAddProductClick() {
        Optional<Integer> quantityOptional = ControllerUtils.getQuantityFromTf(tfQuantity);
        if (quantityOptional.isPresent()) {
            int quantity = quantityOptional.get();
            Roommate addedByRoommate = roommates.stream()
                    .filter(roommate -> roommate.getRoommateName().equals(smbAddedByNames.getText()))
                    .findFirst().orElse(null);
            ShoppingList newProduct = new ShoppingList(tfProductInput.getText(), quantity, addedByRoommate);
            if (!newProduct.getProductName().isEmpty() && newProduct.getQuantity() > 0) {
                shoppingListService.addProductToShoppingList(newProduct);
                shoppingList.add(newProduct);
                clearTextFields();
                dbService.loadShoppingListFromDB();
            }
        } else {
            Tooltip warningTooltip = new Tooltip("please fill in all fields to add a new product");
            Tooltip.install(addProductButton, warningTooltip);
            System.out.println("Bitte füllen Sie alle Felder aus.");
        }
    }
    @FXML
    public void onEditProductClick() {
        ShoppingList selectedProduct = tvShoppingList.getSelectionModel().getSelectedItem();
        String newProduct = tfProductInput.getText();
        Optional<Integer> quantity = ControllerUtils.getQuantityFromTf(tfQuantity);
        Roommate newAddedBy = roommates.stream()
                .filter(roommate -> roommate.getRoommateName().equals(smbAddedByNames.getText()))
                .findFirst().orElse(null);
        if (selectedProduct != null && (newProduct != null || quantity.isPresent() || newAddedBy != null)) {
            shoppingListService.editProductInDB(selectedProduct, newProduct, quantity.orElse(selectedProduct.getQuantity()), newAddedBy);
            clearTextFields();
            dbService.loadShoppingListFromDB();
            tvShoppingList.refresh();
        } else {
            Tooltip warningTooltip = new Tooltip("To edit a product, select the item and enter the new information in the fields");
            Tooltip.install(editProductButton, warningTooltip);
            System.out.println("Bitte wählen ein Produkt zum bearbeiten wählen.");
        }
    }
    @FXML
    public void onDeleteProductClick() {
        ShoppingList selectedProduct = tvShoppingList.getSelectionModel().getSelectedItem();
        if (selectedProduct != null) {
            shoppingListService.deleteProductFromShoppingList(selectedProduct);
            tvShoppingList.getItems().remove(selectedProduct);
        } else {
            Tooltip warningTooltip = new Tooltip("please select a product to delete");
            Tooltip.install(deleteProductButton, warningTooltip);
            System.out.println("Sie haben keine Produkte zum löschen ausgewählt.");
        }
    }

    @FXML
    protected void onPreviousButtonClick () throws IOException {
        Stage stage = (Stage) welcomeLabel.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("hello-view.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
    }

    @FXML
    protected void onInputForQuantityRule(KeyEvent e) {
        UnaryOperator<TextFormatter.Change> filter = change -> {
            Pattern pattern = Pattern.compile("[0-9]*");
            if (pattern.matcher(change.getControlNewText()).matches()) {
                return change;
            } else {
                return null;
            }
        };
        TextFormatter<String> formatter = new TextFormatter<>(filter);
        tfQuantity.setTextFormatter(formatter);

        tfQuantity.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!tfQuantity.getText().isEmpty()) {
                try {
                    int quantity = Integer.parseInt(tfQuantity.getText());
                    System.out.println("Eingegebene Zahl: " + quantity);
                } catch (NumberFormatException numExc) {
                    System.out.println("Ungültige Eingabe: Bitte geben Sie nur Zahlen ein.");
                }
            }
        });
    }
    private void clearTextFields () {
        tfProductInput.clear();
        tfQuantity.clear();
    }
    private void setButtonTooltips() {
        Tooltip tooltipAddProduct = new Tooltip("please fill in all fields");
        addProductButton.setTooltip(tooltipAddProduct);

        Tooltip tooltipDeleteProduct = new Tooltip("deletes the selected product");
        deleteProductButton.setTooltip(tooltipDeleteProduct);

        Tooltip tooltipEditProduct = new Tooltip("please select a product");
        editProductButton.setTooltip(tooltipEditProduct);
    }
}
