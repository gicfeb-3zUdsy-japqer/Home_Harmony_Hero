package com.example.homeharmonyhero;

import com.example.homeharmonyhero.data.Roommate;
import com.example.homeharmonyhero.data.SplitMenuButtonElements;
import com.example.homeharmonyhero.data.Task;
import com.example.homeharmonyhero.logic.DBService;
import com.example.homeharmonyhero.logic.TaskService;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;

public class TaskController {
    @FXML
    private TableView<Task> tvTasksList;

    @FXML
    private TableColumn<Task, Integer> colTaskId;

    @FXML
    private TableColumn<Task, String> colTaskName;

    @FXML
    private TableColumn<Task, Roommate> colAssignedTo;

    @FXML
    private TableColumn<Task, String> colStatus;

    @FXML
    private TextField tfTaskName;

    @FXML
    protected SplitMenuButton markAsStatusButton;

    @FXML
    private Label welcomeLabel;

    @FXML
    private SplitMenuButton sbAssignedTo;

    @FXML
    private Button addTaskButton;

    @FXML
    private Button editTaskButton;

    @FXML
    private Button deleteTaskButton;
    private Stage firstStage;
    TaskService taskService = new TaskService();
    DBService dbService = new DBService();
    public ObservableList<Task> tasksList = taskService.tasksList;

    public ObservableList<Roommate> roommates = dbService.loadRoommatesFromDB();

    @FXML
    public void initialize() {
        addRoommatesToSplitMenuButton();
        addElementsToSplitMenuButton();

        tasksList = dbService.loadTasksFromDB();
        tvTasksList.setItems(tasksList);

        tvTasksList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        colTaskId.setCellValueFactory(new PropertyValueFactory<>("taskId"));
        colTaskName.setCellValueFactory(new PropertyValueFactory<>("taskName"));
        colAssignedTo.setCellValueFactory(new PropertyValueFactory<>("assignedTo"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("taskStatus"));

        setButtonTooltips();
    }
    public void addElementsToSplitMenuButton() {
        SplitMenuButtonElements.addElementsToSplitMenuButton(markAsStatusButton, this::onMarkAsStatusMenuItemClick,
                SplitMenuButtonElements.ERLEDIGT, SplitMenuButtonElements.AUSSTEHEND, SplitMenuButtonElements.IN_ARBEIT);
    }
    public void addRoommatesToSplitMenuButton() {
        ControllerUtils.addRoommatesToSplitMenuButton(sbAssignedTo, roommates, this::onAssignedToMenuItemClick);
    }
    @FXML
    public void onMarkAsStatusMenuItemClick(ActionEvent event) {
        ControllerUtils.onMarkAsStatusMenuItemClick(event, markAsStatusButton);
    }
    @FXML
    public void onAssignedToMenuItemClick(ActionEvent event) {
        ControllerUtils.onAssignedToMenuItemClick(event, sbAssignedTo, roommates);
    }
    @FXML
    public void onAddTaskClick() {
        Roommate selectedRoommate = roommates.stream()
               .filter(roommate -> roommate.getRoommateName().equals(sbAssignedTo.getText()))
               .findFirst().orElse(null);
        String newTaskName = tfTaskName.getText();
        String newTaskStatus = markAsStatusButton.getText();

        if (selectedRoommate != null && newTaskName != null && !newTaskName.isEmpty() && newTaskStatus != null && !newTaskStatus.isEmpty()) {
            Task newTask = new Task(newTaskName, selectedRoommate, newTaskStatus);
            newTask.setTaskId(tasksList.size() + 1);
            newTask.setTaskName(newTaskName);
            newTask.setAssignedTo(selectedRoommate);
            newTask.setTaskStatus(newTaskStatus);

            taskService.addTask(newTask);
            tasksList.add(newTask);
            clearTextFields();
            tvTasksList.refresh();
        } else {
            Tooltip warningTooltip = new Tooltip("please fill in all fields");
            Tooltip.install(addTaskButton, warningTooltip);
            System.out.println("Bitte füllen Sie alle Felder aus.");
        }
   }
   @FXML
   public void onDeleteTaskClick() {
        Task selectedTask = tvTasksList.getSelectionModel().getSelectedItem();

        if (selectedTask != null) {
            taskService.deleteTask(selectedTask);
            tvTasksList.getItems().remove(selectedTask);

        } else {
            Tooltip warningTooltip = new Tooltip("please select a task");
            Tooltip.install(deleteTaskButton, warningTooltip);
            System.out.println("Es wurde kein Aufgaben zum löschen ausgewählt.");
        }
   }
   @FXML
   public void onMarkAsStatusClick() {
        Task selectedTask = tvTasksList.getSelectionModel().getSelectedItem();
        String newStatus = markAsStatusButton.getText();

        if (selectedTask != null && newStatus != null) {
            taskService.markTaskStatus(selectedTask, newStatus);
            taskService.markTaskStatusToDB(selectedTask, newStatus);
        } else {
            Tooltip warningTooltip = new Tooltip("please select a task and a new status");
            Tooltip.install(markAsStatusButton, warningTooltip);
            System.out.println("Keine Aufgabe oder Status ausgewählt");
        }
   }
   @FXML
   public void onOpenEditTaskWindow() throws IOException {
        ObservableList<Task> selectedTasks = tvTasksList.getSelectionModel().getSelectedItems();

        if (selectedTasks != null && !selectedTasks.isEmpty()) {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("edit-task.fxml"));
            Parent root = fxmlLoader.load();
            EditTaskController editTaskController = fxmlLoader.getController();
            editTaskController.setSelectedTasks(selectedTasks);
            editTaskController.setTaskController(this);
            editTaskController.initialize();

            Stage second = new Stage();
            second.setScene(new Scene(root));
            second.setOnCloseRequest(event -> {
                editTaskController.onCloseWindow();
            });

            second.initModality(Modality.APPLICATION_MODAL);
            second.initOwner(welcomeLabel.getScene().getWindow());
            second.showAndWait();
            tvTasksList.refresh();
        } else {
            System.out.println("Bitte wählen Sie mindestens eine Aufgabe zum Bearbeiten aus.");
        }
   }

   @FXML
   protected void onPreviousButtonClick() throws IOException {
        Stage stage = (Stage) welcomeLabel.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("hello-view.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
   }
   private void setButtonTooltips() {
        Tooltip tooltipDeleteTask = new Tooltip("deletes the selected task");
        deleteTaskButton.setTooltip(tooltipDeleteTask);

        Tooltip tooltipEditTask = new Tooltip("please select at least one task");
        editTaskButton.setTooltip(tooltipEditTask);
   }
   public void updateTasksListAfterEdit(Task deletedTask) {
        tasksList.remove(deletedTask);
        tvTasksList.refresh();
   }
   private void clearTextFields() {
        tfTaskName.clear();
   }
}