package com.example.homeharmonyhero.logic;
import com.example.homeharmonyhero.data.Roommate;
import com.example.homeharmonyhero.data.Task;
public class AssignedToEditCondition implements TaskEditCondition {
    @Override
    public void execute(Task selectedTask, TaskService taskService, Roommate newAssignedTo, String newStatus, String newTaskName) {
        if (newAssignedTo != null) {
            taskService.editAssignedToToDB(selectedTask, newAssignedTo.getRoommateName());
            selectedTask.setAssignedTo(newAssignedTo);
        }
    }
}