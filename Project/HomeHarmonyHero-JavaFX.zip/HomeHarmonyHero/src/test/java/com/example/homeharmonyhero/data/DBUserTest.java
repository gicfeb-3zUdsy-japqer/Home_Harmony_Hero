package com.example.homeharmonyhero.data;

import org.junit.jupiter.api.Test;

class DBUserTest {
    @Test
    public void test(){
       DBUser test = new DBUser();
        System.out.println(test.getDbUrl() + " " + test.getUser() + " " + test.getPw());
    }
}